import java.util.Comparator;

/**
 * @author ericfouh
 */
public interface ITerm
    extends Comparable<ITerm> {
    
    /**
     * Compares the two terms in descending order by weight.
     * 
     * @return comparator Object
     */
    public static Comparator<ITerm> byReverseWeightOrder() {
        Comparator<ITerm> c = new Comparator<ITerm>() {
            public int compare(ITerm term1, ITerm term2) {
                return (int) (((Term)term2).getWeight() - ((Term)term1).getWeight());
            }
        };
        return c;
    }

    /**
     * Compares the two terms in descending order by weight.
     * @return comparator Object
     */
    public static Comparator<ITerm> wordTermWeightOrder() {
        Comparator<ITerm> c = new Comparator<ITerm>() {
            
            // override compare method
            public int compare(ITerm i1, ITerm i2) {
                if (WordTerm.class.isInstance(i1) && WordTerm.class.isInstance(i2)) {
                    // if i1 and i2 are both WordTerm objects
                    return (int) ((WordTerm) i1).getWeight() - ((WordTerm) i2).getWeight();
                } else if (WordTerm.class.isInstance(i1) && Term.class.isInstance(i2)) {
                    // else if only i1 is a WordTerm object and i2 is a Term object
                    return (int) ((long) ((WordTerm) i1).getWeight() - ((Term) i2).getWeight());
                } else if (Term.class.isInstance(i1) && WordTerm.class.isInstance(i2)) {
                    // else if only i2 is a WordTerm object and i1 is a Term object
                    return (int) (((Term) i1).getWeight() - (long) ((WordTerm) i2).getWeight());
                } else {
                    // if i1 and i2 are both Term objects
                    return (int) (((Term) i1).getWeight() - ((Term) i2).getWeight());
                }
            }
        };
        
        return c;
    }

    /**
     * Compares the two terms in lexicographic order but using only the first r
     * characters of each query.
     * 
     * @param r
     * @return comparator Object
     */
    public static Comparator<ITerm> byPrefixOrder(int r) {
        if (r < 0) {
            throw new IllegalArgumentException();
        }
        
        Comparator<ITerm> c = new Comparator<ITerm>() {
            public int compare(ITerm term1, ITerm term2) {
                String q1 = ((Term)term1).getTerm();
                String q2 = ((Term)term2).getTerm();
                int l1 = q1.length();
                int l2 = q2.length();
                int min = Math.min(l1, l2);
                int l = r;
                if (r > min) {
                    l = min;
                }
                return q1.substring(0, l).compareTo(q2.substring(0, l));
            }
        };
        
        return c;
    }

    // Compares the two terms in lexicographic order by query.
    public int compareTo(ITerm that);


    // Returns a string representation of this term in the following format:
    // the weight, followed by a tab, followed by the query.
    public String toString();

}
