import java.util.Comparator;

/**
 * @author ericfouh
 */
public interface ITerm
    extends Comparable<ITerm> {

    /**
     * Compares the two terms in descending order by weight.
     * @return comparator Object
     */
    public static Comparator<ITerm> wordTermWeightOrder() {
        Comparator<ITerm> c = new Comparator<ITerm>() {
            
            // override compare method
            public int compare(ITerm i1, ITerm i2) {
                if (WordTerm.class.isInstance(i1) && WordTerm.class.isInstance(i2)) {
                    // if i1 and i2 are both WordTerm objects
                    return (int) ((WordTerm) i1).getWeight() - ((WordTerm) i2).getWeight();
                } else if (WordTerm.class.isInstance(i1) && Term.class.isInstance(i2)) {
                    // else if only i1 is a WordTerm object and i2 is a Term object
                    return (int) ((long) ((WordTerm) i1).getWeight() - ((Term) i2).getWeight());
                } else if (Term.class.isInstance(i1) && WordTerm.class.isInstance(i2)) {
                    // else if only i2 is a WordTerm object and i1 is a Term object
                    return (int) (((Term) i1).getWeight() - (long) ((WordTerm) i2).getWeight());
                } else {
                    // if i1 and i2 are both Term objects
                    return (int) (((Term) i1).getWeight() - ((Term) i2).getWeight());
                }
            }
        };
        
        return c;
    }

    // Compares the two terms in lexicographic order by query.
    public int compareTo(ITerm that);

    // Returns a string representation of this term in the following format:
    // the weight, followed by a tab, followed by the query.
    public String toString();

}
