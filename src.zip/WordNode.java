import java.util.ArrayList;
import java.util.TreeMap;

/**
 * ==== Attributes ====
 * - phrases: number of phrases
 * - term: the ITerm object
 * - prefixes: number of prefixes
 * - references: Array of references to next/children Nodes
 *
 * ==== Constructor ====
 * WordNode(String query, long weight)
 *
 * @author Your_Name
 */
public class WordNode {
    
    // declare all field variables for the wordNode class
    private int phrases;
    private WordTerm wordTerm;
    private int prefixes;
    private ArrayList<WordNode> references;
    private String nthWord;

    /**
     * Constructor for WordNode: takes 3 inputs
     * @param ref nth word in an n-gram sequence
     * @param query n-gram sequence list
     * @param weight of an n-gram sequence
     */
    public WordNode(String ref, ArrayList<String> query, int weight) {
        // edge case: throw exception if query is null or weight is negative
        if (query == null || weight < 0) {
            throw new IllegalArgumentException("Not valid input");
        }
        
        // initialize all field variables
        this.nthWord = ref;
        this.wordTerm = new WordTerm(query, weight);
        this.phrases = 0;
        this.prefixes = 0;
        this.references = new ArrayList<WordNode>();
    }

    /**
     * Constructor for WordNode: takes 1 input
     * @param ref nth word in an n-gram sequence
     */
    public WordNode(String ref) {
        // initialize all field variables
        this.nthWord = ref;
        this.wordTerm = null;
        this.phrases = 0;
        this.prefixes = 0;
        this.references = new ArrayList<WordNode>();
    }
    
    /**
     * @return int number of phrases in the children of this wordNode
     */
    protected int getPhrases() {
        return phrases;
    }

    /**
     * @param phrases in the children of this wordNode
     */
    protected void setPhrases(int phrases) {
        this.phrases = phrases;
    }

    /**
     * @return WordTerm object referenced by this word node
     */
    protected WordTerm getTerm() {
        return wordTerm;
    }

    /**
     * @param term WordTerm object to be referenced by this word node
     */
    protected void setTerm(WordTerm term) {
        this.wordTerm = term;
    }

    /**
     * @param int number of prefixes in the children of this word node
     */
    protected int getPrefixes() {
        return prefixes;
    }

    /**
     * @param prefixes in the children of this word node
     */
    protected void setPrefixes(int prefixes) {
        this.prefixes = prefixes;
    }

    /**
     * @return encapsulated references collection to all children of this word node
     */
    protected ArrayList<WordNode> getReferences() {
        return references;
    }

    /**
     * @param references to set the references collection of this node to
     */
    protected void setReferences(ArrayList<WordNode> references) {
        this.references = references;
    }

    /**
     * @return the nth word represented by this word node
     */
    protected String getNthWord() {
        return nthWord;
    }

    /**
     * @param nthWord to be represented by this word node
     */
    protected void setNthWord(String nthWord) {
        this.nthWord = nthWord;
    }

}
