import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;
import java.util.AbstractMap.SimpleEntry;

public class NGramAutocomplete implements INGramAutocomplete {

    // class field variables
    private WordNode nGramRoot = new WordNode("");
    private Map<String, Long> wordFreq = new HashMap<>();
    
    /**
     * <parseFile> Parse the document and return a Map of each
     * n-gram phrase and the times it occurred in the file. (punctuation and special characters
     * removed)
     * Create a file that has every word and its occurred time, in the format that the autocomplete
     * buildTrie function needs.
     *
     * @param filename the file to parse
     * @param n the number of words in the n-gram model
     * @return a Map of list of words in each n-gram phrase and the times it occurred in the file
     */
    @Override
    public Map<ArrayList<String>, Integer> parseFile(String filename, int n) {
        
        // initialize variables for file reading
        String s = null;
        BufferedReader r = null;
        // map to store a list containing a n-length phrase and its frequency
        Map<ArrayList<String>, Integer> map = new HashMap<>();

        try {
            // initialize the bufferedreader with a filereader from input String filename
            r = new BufferedReader(new FileReader(filename));

            // read until reaching the end of the file
            while ((s = r.readLine()) != null) {
                
                // break if the line is empty
                if (s.equals("")) {
                    break;
                }

                // split each input line into weight and an n-gram phrase
                String[] spt = s.trim().split("\\s+");

                // parse weight from the above split string
                int weight = Integer.parseInt(spt[0]);

                // files are organized by frequency; once below the frequency limit, stop reading
                if (weight < INGramAutocomplete.FREQ_LIMIT) {
                    break;
                }

                // create an ArrayList from the String array above and remove the weight element
                ArrayList<String> nGrams = new ArrayList<String>(Arrays.asList(spt));
                nGrams.remove(0);
                
                // loop through all n words in the nGrams array list
                for (int i = 0; i < n; i++) {
                    // get the String at position i
                    String word = nGrams.get(i);
                    // if the word is not yet in the wordFreq map, put it there with value 0
                    if (this.wordFreq.get(word) == null) {
                        this.wordFreq.put(word, (long) 0);
                    }
                    // increment by weight the count of the of the word in the wordFreq map
                    this.wordFreq.put(word, this.wordFreq.get(word) + weight);
                }

                // put the nGrams list to the above defined map with its weight read from the file
                map.put(nGrams, weight);

            }
            
            // close the buffered reader and return the map
            r.close();
            return map;
        } catch (IOException e) {
            // catch any IO Exceptions during reading
            e.printStackTrace();
        }
        
        // return null if the file reading fails
        return null;
    }
    
    /**
     * Create a file containing all the words in the files. Each word
     * should occupy a line Words should be written in lexicographic order assign the
     * frequency of each word as weight. The method must store the words into a file named
     * autocomplete.txt
     *
     * @param files the list of the filenames
     */
    @Override
    public void createAutoCompleteFile() {
        
        try {
            // create a fileWriter to link to the file "autocomplete.txt"
            FileWriter myWriter = new FileWriter("autocomplete.txt");
            // write and flush an empty String
            myWriter.write("");
            myWriter.flush();
            // create a bufferedwriter with the fileWriter
            BufferedWriter myBufWriter = new BufferedWriter(myWriter);
            
            // initialize a LinkedHashMap to store word frequencies sorted by weight
            LinkedHashMap<String, Long> sortedWordFreq = new LinkedHashMap<>();
            
            // using a set of the word frequency map from parseFile sorted by weight, 
            // put each ordered (key, value) pair into the sortedWordFreq map 
            this.getWordFreq().entrySet()
            .stream()
            .sorted(Map.Entry.comparingByValue(Comparator.reverseOrder()))
            .forEachOrdered(x -> sortedWordFreq.put(x.getKey(), x.getValue()));
            
            // write the header of the autocomplete file: total number of words as a String
            String header = this.getWordFreq().size() + "\n";
            myBufWriter.write(header);
            
            // loop through each key in the sorted word frequency map
            for (String word: sortedWordFreq.keySet()) {
                // write the weight of the word and the word as a string on a line
                myBufWriter.append(sortedWordFreq.get(word) + "  " + word + "\n");
                // flush the buffered writer
                myBufWriter.flush();
            }
            
            // close the buffered writer
            myBufWriter.close();
        } catch (IOException e) {
            // catch any IO exceptions encountered during file writing
            e.printStackTrace();
        }

    }
    
    /**
     * @param docs a map computed by {@parseFile}
     * @return the forward index: a map of the first n-1 words of all phrases and
     *         the last word of that phrase, the value is a map of different last
     *         words and their frequency.
     *         The values (Map<String, Double>) are sorted by
     *         lexicographic order on the key (tag term).
     *         Each inner map is sorted by descending order on the frequency(its value).
     */
    @Override
    public Map<ArrayList<String>, TreeSet<SimpleEntry<String, Integer>>> 
        buildNGramIndex(Map<ArrayList<String>, Integer> map) {

        // call the createComparator helper function to get a new comparator for sorting
        Comparator<SimpleEntry<String, Integer>> c = this.createComparator();
        // indexMap to map an arrayList of n-1 word sequences to a treeSet of 1-word endings
        Map<ArrayList<String>, TreeSet<SimpleEntry<String, Integer>>> indexMap = new HashMap<>();
        
        // loop through the keyset of the input map
        for (ArrayList<String> ngram: map.keySet()) {
            // get the frequency (value) of the ngram key
            int freq = map.get(ngram);
            // get the final word of the ngram key sequence
            String last = ngram.get(ngram.size() - 1);
            // remove the final word of the ngram key sequence
            ngram.remove(ngram.size() - 1);
            
            // check if the indexMap contains the n-1 word sequence stored in the ngram variable
            if (!indexMap.containsKey(ngram)) {
                // if not, create a new TreeSet to store 1-word endings to the n-1 word sequence
                TreeSet<SimpleEntry<String, Integer>> lastSet =
                        new TreeSet<SimpleEntry<String, Integer>>(c);
                // put the ngram sequence and treeSet into the indexMap
                indexMap.put(ngram, lastSet);
            }

            // create a new SimpleEntry object with key equal to the nth word from the sequence
            // and value equal to the frequency of that entire n-word sequence
            SimpleEntry<String, Integer> s = new SimpleEntry<String, Integer>(last, freq);
            
            // add the simpleEntry object to the treeSet corresponding to the n-1 word sequence
            indexMap.get(ngram).add(s);

        }

        // return the completed index map
        return indexMap;
    }
    
    /**
     * Helper function used to create a comparator to sort SimpleEntry objects by value
     * @return a new Comparator object
     */
    private Comparator<SimpleEntry<String, Integer>> createComparator() {
        // create a new comparator object
        return new Comparator< SimpleEntry<String, Integer>>() {
            // override the compare method
            public int compare(SimpleEntry<String, Integer> e1, SimpleEntry<String, Integer> e2) {
                // compare by the natural ordering of the Int values
                return e2.getValue().compareTo(e1.getValue());
            }
        };
    }
    
    /**
     * Helper function (public for testing) used by the buildNGramTrie method 
     * Used to add a NGram Node (Word Node) to the NGram Trie
     * Also calls the private helper function addNGramNode
     * @param ngram String containing a n-1 word phrase
     * @param weight frequency of that phrase
     */
    public void addNGram(ArrayList<String> ngram, int weight) {

        // check that the word is valid (all alphabetical characters)
        int length = ngram.size();
        // loop through each word in the ngram string
        for (int i = 0; i < length; i++) {
            // loop through each character in the word
            for (int j = 0; j < ngram.get(i).length(); j++) {
                // all characters should be alphabetical characters
                if (!Character.isLetter(ngram.get(i).charAt(j))) {
                    // do not add a word if it is invalid; break and do nothing
                    return;
                }
            }
            
            // convert the word to all lowercase
            ngram.set(i, ngram.get(i).toLowerCase());
        }
        
        // initialize a list of all remaining words in the n-1 word sequence
        ArrayList<String> remainingWords = new ArrayList<String>();
        // add all words from the input ngram list to the above list
        for (int i = 0; i < ngram.size(); i++) {
            remainingWords.add(ngram.get(i));
        }
        // add a Node with appropriate weight and word array
        this.addNGramNode(remainingWords, weight, this.getnGramRoot(), ngram);

    }
    
    /**
     * Recursive private helper function useds to add a WordNode to the NGram Trie
     * Starts at the NGram root and recurses down in steps
     * @param remainWords list of remaining words in the original n-word list
     * @param weight of an ngram sequence
     * @param wordNode current position in the trie
     * @param ngram n-word ngram list
     */
    private void addNGramNode(
            ArrayList<String> remainWords, int weight, WordNode wordNode, ArrayList<String> ngram) {
        
        // get the first word of the remaining word sequence and the number of words remaining
        String firstWord = remainWords.get(0);
        int len = remainWords.size();
        // increment the current node's prefix field variable by 1
        wordNode.setPrefixes(wordNode.getPrefixes() + 1);
        // get the references of the current wordNode
        ArrayList<WordNode> ref = wordNode.getReferences();
        
        // if more than 1 word remain in the ngram sequence
        if (len > 1) {
            // check if the next word is not in the current node's references
            if (this.findWordRef(wordNode, firstWord) == null) {
                // create a new WordNode for the next word
                WordNode newNode = new WordNode(firstWord);
                // add the node to the current node's references and update them
                ref.add(newNode);
                wordNode.setReferences(ref);
            }
        } else if (len == 1) { // if only 1 word remains in the ngram sequence
            // check if the next word is not in the current node's references
            if (this.findWordRef(wordNode, firstWord) == null) {
                // create a new WordNode for the next word
                WordNode newNode = new WordNode(firstWord, ngram, weight);
                // increment the new node's phrases and prefixes count
                newNode.setPhrases(newNode.getPhrases() + 1);
                newNode.setPrefixes(newNode.getPrefixes() + 1);
                // add the node to the current node's references and update them
                ref.add(newNode);
                wordNode.setReferences(ref);
                // break the recursion since no more words remain
                return;
            } else {
                // get the existing word node for the next word
                WordNode wnode = findWordRef(wordNode, firstWord);
                // increment the node's phrases and prefixes count
                wnode.setPrefixes(wnode.getPrefixes() + 1);
                wnode.setPhrases(wnode.getPhrases() + 1);
                
                // break the recursion since no words remain
                return;
            }
            
        }
        
        // remove the first word from the ngram list and recurse with updated list and word node
        remainWords.remove(0);
        this.addNGramNode(remainWords, weight, findWordRef(wordNode, firstWord), ngram);
    }
    
    /**
     * Helper function used to find a word node by String word
     * Called by multiple functions in building the ngram trie
     * Public for testing
     * @param wordNode to search through
     * @param word to find
     * @return the appropriate node if one exists or null if word is not found
     */
    public WordNode findWordRef(WordNode wordNode, String word) {
        // get the word node's references
        ArrayList<WordNode> ref = wordNode.getReferences();
        // loop through all children in the references list
        for (int i = 0; i < ref.size(); i++) {
            // get the final word corresponding to each node
            String nthWord = ref.get(i).getNthWord();
            // return the node if the words match
            if (nthWord.equals(word)) {
                return ref.get(i);
            }
        }
        // if no words match, return null
        return null;
    }
    
    /**
     * Initializes the N-Gram suggestions Trie
     *
     * @param nGramMaps a list of maps that the Map of the first n-1 words of all phrases and the
     *                   last word of that phrase, the value is a map of different
     *                   last words and their frequency.
     * @param k the maximum number of suggestions that should be displayed
     * @return the root of the N-Gram Trie
     */
    @Override
    public WordNode buildNGramTrie(ArrayList<Map<ArrayList<String>, Integer>> nGramMaps) {
        
        // loop through all of the input nGramMaps
        for (Map<ArrayList<String>, Integer> nGramMap : nGramMaps) {
            // get each n-1 word phrase from the keyset of the nGramMap
            for (ArrayList<String> phrase: nGramMap.keySet()) {
                // call the add NGram method helper function
                this.addNGram(phrase, nGramMap.get(phrase));
            }
        }
        
        // return the ngram root
        return this.nGramRoot;
    }
    
    /**
     * This method should not throw an exception
     * @param prefix
     * @return a List containing all the ITerm objects with query starting with
     *         prefix. Return an empty list if there are no ITerm object starting
     *         with prefix.
     */
    public WordNode getNGramSubTrie(ArrayList<String> preWords) {
        // check if the prefix words list is null or empty
        if (preWords == null || preWords.size() == 0) {
            // return null - dont return any suggestions
            return null;
        }
        
        // if the only input is empty text, return the nGramRoot
        if (preWords.size() == 1 && preWords.get(0).equals("")) {
            return this.nGramRoot;
        }
        
        // make sure that the input prefix list is valid
        int length = preWords.size();
        // loop through all of the words in the list
        for (int i = 0; i < length; i++) {
            // loop through each character in the word
            for (int j = 0; j < preWords.get(i).length(); j++) {
                // all characters should be alphabetical characters
                if (!Character.isLetter(preWords.get(i).charAt(j))) {
                    // do not add a word if it is invalid
                    return null;
                }
            }
        }
        
        // get the word node at the root of the ngram trie
        WordNode wn = this.nGramRoot;
        // loop through the length of the prefix list
        for (int i = 0; i < preWords.size(); i++) {
            // if the prefix word can be found in the wordNode's references
            WordNode child = this.findWordRef(wn, preWords.get(i));
            if (child != null) {
                // update the wordNode to the appropriate child node
                wn = child;
            } else {
                // return null otherwise
                return null;
            }
        }
        
        // return the last word node
        return wn;
    }
    
    /**
     * Get the number of prefixes of an input prefix list
     * @param prefix list of prefix strings
     * @return the number of prefixes of that list
     */
    public int countNGramPrefixes(ArrayList<String> prefix) {
        // get the subTrie Node of the input prefix list
        WordNode subTrie = getNGramSubTrie(prefix);
        // if the Node is null, return 0
        if (subTrie == null) {
            return 0;
        }
        // otherwise, return the number of prefix at that node
        return subTrie.getPrefixes();
    }
    
    /**
     * This method should not throw an exception
     * @param prefix
     * @return a List containing all the ITerm objects with query starting with
     *         prefix. Return an empty list if there are no ITerm object starting
     *         with prefix.
     */
    @Override
    public List<ITerm> getNGramSuggestions(ArrayList<String> prefix) {
        // create a new array list to store ITerm objects starting with input prefix
        List<ITerm> wordTermList = new ArrayList<>();
        // get the subtrie corresponding to the input prefix list
        WordNode node = this.getNGramSubTrie(prefix);
        // call the traverseNGramSubtrie helper function to add all prefixes to wordTermList
        this.traverseNGramSubTrie(node, wordTermList);
        // return the list
        return wordTermList;
    }
    
    /**
     * Helper function used to traverse the nGram SubTrie from getNGramSuggestions
     * Adds WordTerm objects to the list to be returned while traversing the Trie
     * @param wordNode current WordNode in the recursion process
     * @param list to add all WordTerm objects to
     */
    private void traverseNGramSubTrie(WordNode wordNode, List<ITerm> list) {
        // if the input wordNode is null, break
        if (wordNode == null) {
            return;
        }
        
        // if the wordNode corresponds to a non-zero number of phrases
        if (wordNode.getPhrases() > 0) {
            // get the phrase list stored in that wordNode
            WordTerm wt = wordNode.getTerm();
            ArrayList<String> phrase = wt.getPhrase();
            // get the weight of the wordTerm
            int weight = wt.getWeight();
            // add a new WordTerm object with appropriate phrase and weight
            list.add(new WordTerm(phrase, weight));
        }
        
        // get all references of the wordNode
        ArrayList<WordNode> ref = wordNode.getReferences();
        
        // traverse each reference subtrie recursively
        for (int i = 0; i < ref.size(); i++) {
            this.traverseNGramSubTrie(ref.get(i), list);
        }
        
    }
    
    /**
     * This method takes the user input as parameter and call the letter level
     * autocomplete getSuggestions and phrase level getNGramSuggestions, return
     * the combined suggestion of both functions
     * @param prefix
     * @return a List containing all the ITerm objects with query starting with
     *         prefix. Return an empty list if there are no ITerm object starting
     *         with prefix.
     */
    @Override
    public List<ITerm> completeMe(String prefix, Autocomplete atc) {
        
        // create an ITerm arraylist of suggestions to be returned
        List<ITerm> suggestions = new ArrayList<ITerm>();
        // split the prefix on spaces and create a list of prefix words from it
        String[] preWords = prefix.trim().split("\\s+");
        ArrayList<String> preWordsList = new ArrayList<String>(Arrays.asList(preWords));
        
        // get the last word in the prefix string if it is longer than 1 word
        String lastWord;
        if (preWords.length > 1) {
            lastWord = preWords[preWords.length - 1];
        } else {
            lastWord = prefix;
        }
        
        // get the last sequence in the prefix string if it is longer than 4 words (only do 5-gram)
        ArrayList<String> lastSequence = new ArrayList<String>();
        int size = preWordsList.size();
        if (size > 4) {
            List<String> sublist = preWordsList.subList(size - 4, size);
            lastSequence.addAll(sublist);
        } else {
            lastSequence = preWordsList;
        }
        
        // get the autocomplete word suggestions and N-Gram suggestions
        List<ITerm> wordSug = atc.getSuggestions(lastWord);
        List<ITerm> phraseSug = this.getNGramSuggestions(lastSequence);
        
        // add any autocomplete word suggestions to the suggestions list
        if (wordSug.size() != 0) {
            suggestions.addAll(wordSug);
        }
        // add any n-gram word suggestions to the suggestions list
        if (phraseSug.size() != 0) {
            suggestions.addAll(phraseSug);
        }
        
        return suggestions;
    }
    
    /**
     * @return word frequency map
     */
    public Map<String, Long> getWordFreq() {
        return wordFreq;
    }
    
    /**
     * @param set word frequency map
     */
    public void setWordFreq(Map<String, Long> wordFreq) {
        this.wordFreq = wordFreq;
    }

    /**
     * @return the ngram root
     */
    public WordNode getnGramRoot() {
        return this.nGramRoot;
    }
}
