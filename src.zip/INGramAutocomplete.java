import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;
import java.util.AbstractMap.SimpleEntry;

public interface INGramAutocomplete {

    public static final int FREQ_LIMIT = 2000;
    
    /**
     * <parseFile> Parse the document and return a Map of each
     * n-gram phrase and the times it occurred in the file. (punctuation and special characters
     * removed)
     * Create a file that has every word and its occurred time, in the format that the autocomplete
     * buildTrie function needs.
     *
     * @param filename the file to parse
     * @param n the number of words in the n-gram model
     * @return a Map of list of words in each n-gram phrase and the times it occurred in the file
     */
    public Map<ArrayList<String>, Integer> parseFile(String filename, int n);
    
    /**
     * Create a file containing all the words in the files. Each word
     * should occupy a line Words should be written in lexicographic order assign the
     * frequency of each word as weight. The method must store the words into a file named
     * autocomplete.txt
     *
     * @param files the list of the filenames
     */
    public void createAutoCompleteFile();
    
    /**
     * @param map a map computed by {@parseFile}
     * @return the forward index: a map of the first n-1 words of all phrases and
     *         the last word of that phrase, the value is a map of different last
     *         words and their frequency.
     *         The values (Map<String, Double>) are sorted by
     *         lexicographic order on the key (tag term).
     *         Each inner map is sorted by descending order on the frequency(its value).
     */
    public Map<ArrayList<String>, TreeSet<SimpleEntry<String, Integer>>> 
        buildNGramIndex(Map<ArrayList<String>, Integer> map);
    
    /**
     * Helper function (public for testing) used by the buildNGramTrie method 
     * Used to add a NGram Node (Word Node) to the NGram Trie
     * Also calls the private helper function addNGramNode
     * @param ngram String containing a n-1 word phrase
     * @param weight frequency of that phrase
     */
    public void addNGram(ArrayList<String> ngram, int weight);
    
    /**
     * Initializes the N-Gram suggestions Trie
     *
     * @param nGramIndex a list of maps that the Map of the first n-1 words of all phrases and the
     *                   last word of that phrase, the value is a map of different
     *                   last words and their frequency.
     * @return the root of the N-Gram Trie
     */
    public WordNode buildNGramTrie(ArrayList<Map<ArrayList<String>, Integer>> nGramIndex);
    
    /**
     * This method should not throw an exception
     * @param prefix
     * @return a List containing all the ITerm objects with query starting with
     *         prefix. Return an empty list if there are no ITerm object starting
     *         with prefix.
     */
    public WordNode getNGramSubTrie(ArrayList<String> preWords);
    
    /**
     * This method should not throw an exception
     * @param prefix
     * @return a List containing all the ITerm objects with query starting with
     *         prefix. Return an empty list if there are no ITerm object starting
     *         with prefix.
     */
    public List<ITerm> getNGramSuggestions(ArrayList<String> prefix);
    
    /**
     * Get the number of prefixes of an input prefix list
     * @param prefix list of prefix strings
     * @return the number of prefixes of that list
     */
    public int countNGramPrefixes(ArrayList<String> prefix);
    
    /**
     * This method takes the user input as parameter and call the letter level
     * autocomplete getSuggestions and phrase level getNGramSuggestions, return
     * the combined suggestion of both functions
     * @param prefix String entered in the search box
     * @param atc an Autocomplete object used to get results from
     * @return a List containing all the ITerm objects with query starting with
     *         prefix. Return an empty list if there are no ITerm object starting
     *         with prefix.
     */
    public List<ITerm> completeMe(String prefix, Autocomplete atc);
    
}
