import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Map;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

/**
 * @author ericfouh
 */
public class AutocompleteGUI {

    private JFrame frame;
    private Autocomplete atc;
    private AutocompletePanel searchBox;
    private int numSuggestions = 5;


    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    AutocompleteGUI window = new AutocompleteGUI();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }


    /**
     * Create the application.
     */
    public AutocompleteGUI() {
        initialize();
    }


    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {
        this.atc = new Autocomplete();   
        
        frame = new JFrame();
        frame.setBounds(100, 100, 450, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        DefaultListModel<String> articlesList = new DefaultListModel<String>();
        JList<String> results = new JList<String>(articlesList);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setViewportView(results);
        results.setLayoutOrientation(JList.VERTICAL);
        scrollPane.setVisible(true);

        JPanel panel = new JPanel(new BorderLayout());
        panel.add(scrollPane);
        panel.setBounds(0, 270, 450, 300);

        frame.add(panel);

        JButton btnParse = new JButton("Parse N-Gram");
        btnParse.setBounds(0, 32, 117, 29);
        btnParse.setEnabled(true);
        frame.getContentPane().add(btnParse);

        JButton buildFile = new JButton("Create File");
        buildFile.setToolTipText("Build Autocomplete File");
        buildFile.setBounds(129, 32, 117, 29);
        buildFile.setEnabled(false);
        frame.getContentPane().add(buildFile);

        JButton btnAutoCplt = new JButton("Autocomplete");
        btnAutoCplt.setToolTipText("Build Autocomplete Trie");
        btnAutoCplt.setBounds(250, 32, 117, 29);
        btnAutoCplt.setEnabled(true);
        frame.getContentPane().add(btnAutoCplt);

        JButton type = new JButton("Ready to Type");
        type.setToolTipText("Button enabled once autocomplete is ready");
        type.setBounds(129, 70, 117, 29);
        type.setEnabled(false);
        frame.getContentPane().add(type);

        searchBox = new AutocompletePanel("autocomplete.txt", atc, null, numSuggestions);
        searchBox.setBounds(0, 135, 350, 130);
        searchBox.setVisible(true);
        frame.getContentPane().add(searchBox);     
        
        // Parse file
        btnParse.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                // call ngram parseFile on all dataset files
                Map<ArrayList<String>, Integer> m2 = atc.parseFile("ngrams_words_2.txt", 2);
                Map<ArrayList<String>, Integer> m3 = atc.parseFile("ngrams_words_3.txt", 3);
                Map<ArrayList<String>, Integer> m4 = atc.parseFile("ngrams_words_4.txt", 4);
                Map<ArrayList<String>, Integer> m5 = atc.parseFile("ngrams_words_5.txt", 5);
                
                // create a list to contain all ngram maps
                ArrayList<Map<ArrayList<String>, Integer>> nGramMaps = new ArrayList<>();
                // add all maps to the arrayList
                nGramMaps.add(m2);
                nGramMaps.add(m3);
                nGramMaps.add(m4);
                nGramMaps.add(m5);
                
                atc.buildNGramTrie(nGramMaps, numSuggestions);
                buildFile.setEnabled(true);
            }

        });
        
        // Autocomplete
        buildFile.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                atc.createAutoCompleteFile();
                btnAutoCplt.setEnabled(true);
            }

        });
        
        // Build autocomplete trie
        btnAutoCplt.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                Node root = atc.buildTrie("autocomplete.txt", numSuggestions);
                searchBox = new AutocompletePanel("autocomplete.txt", atc, root, numSuggestions);
                type.setEnabled(true);
            }

        });

    }
}
