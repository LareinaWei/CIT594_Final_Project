import java.util.ArrayList;

public class WordTerm implements ITerm {
    
    ArrayList<String> phrase;
    int weight;
    
    /**
     * Class constructor : takes a phrase (String ArrayList) and weight (int)
     * @param phrase
     * @param weight
     */
    public WordTerm(ArrayList<String> phrase, int weight) {
        // edge case
        if (phrase == null || phrase.size() == 0 || weight < 0) {
            throw new IllegalArgumentException("Not valid input");
        }
        
        this.phrase = phrase;
        this.weight = weight;
    }
    
    protected ArrayList<String> getPhrase() {
        return phrase;
    }

    protected void setPhrase(ArrayList<String> phrase) {
        this.phrase = phrase;
    }

    protected int getWeight() {
        return weight;
    }

    protected void setWeight(int weight) {
        this.weight = weight;
    }

    /**
     * Override toString method for printing, similar to provided Term toString
     */
    @Override
    public String toString() {
        if (this.phrase == null || this.phrase.size() == 0) {
            return "";
        }
        String p = this.getWeight() + "\t";
        for (int i = 0; i < this.phrase.size() - 1; i++) {
            p += phrase.get(i);
            p += " ";
        }
        p += phrase.get(phrase.size() - 1);
        return p;
    }
    
    /**
     * Override compareTo method to allow for sorting by phrase
     */
    @Override
    public int compareTo(ITerm that) {        
        return this.phrase.toString().compareTo(((WordTerm)that).getPhrase().toString());
    }
}
