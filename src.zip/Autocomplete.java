import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Autocomplete implements IAutocomplete {

    // class field variables
    private int numSuggestions;
    private Node root = new Node("", 0);

    /**
     * Adds a new word with its associated weight to the autocomplete Trie
     * 
     * @param word the word to be added to the Trie
     * @param w the weight of the word
     */
    @Override
    public void addWord(String word, long w) {

        // check if the word is valid
        int length = word.length();
        for (int i = 0; i < length; i++) {
            // all characters should be alphabetical characters
            if (!Character.isLetter(word.charAt(i))) {
                // do not add a word if it is invalid
                return;
            }
        }

        // add a Node with appropriate weight and String converted to lower case
        String lowerWord = word.toLowerCase();
        this.addNode(lowerWord, w, this.root, lowerWord);

    }

    /**
     * Helper function used to add a node to the Trie
     * Handles incrementing prefixes and words field variables of the Node class
     * Updates Node references when new nodes are added or changed
     * @param str recursive string, decreasing in length for each iteration
     * @param w of the Term
     * @param node current Node in recursion; traverses over the length of the trie
     * @param word complete word to be added to the Trie at the final step of recursion
     */
    private void addNode(String str, long w, Node node, String word) {
        
        // get the first letter in the input String str
        char letter = str.charAt(0);
        // map the int value of the char to have 'a' be 0
        int index = letter - 'a';
        // get the length of the string
        int len = str.length();
        
        // increment the number of prefixes this node corresponds to and get its references
        node.setPrefixes(node.getPrefixes() + 1);
        Node[] ref = node.getReferences();
        // if this node is not a leaf node
        if (len > 1) {
            // if the appropriate character of this node's references list is empty
            if (ref[index] == null) {
                // initialize a new node at the appropriate index and update node's references
                ref[index] = new Node();
                node.setReferences(ref);
            }
        } else if (len == 1) { // if it is a leaf node
            // if the appropriate character of this node's references list is empty
            if (ref[index] == null) {
                // initialize a new node with Term equal to the full-length input word
                ref[index] = new Node(word, w);
                // increment the word and prefix field variable of the node at index
                ref[index].setWords(ref[index].getWords() + 1);
                ref[index].setPrefixes(ref[index].getPrefixes() + 1);
                // update the node's references list
                node.setReferences(ref);
                // reached a leaf node, so we can break from this function
                return;
            } else { // if the character of this node's references list is not empty
                // set the Node's Term to a new term
                ref[index].setTerm(new Term(word, w));
                // update the prefix and words field variables of the node
                ref[index].setPrefixes(ref[index].getPrefixes() + 1);
                ref[index].setWords(ref[index].getWords() + 1);
                // update the node's references list
                node.setReferences(ref);
                // reached a leaf node, so we can break from this function
                return;
            }
        }

        // recurse into this function, removing the first char from str and moving to the next node
        this.addNode(str.substring(1), w, node.getReferences()[index], word);
    }

    /**
     * Initializes the word autocomplete Trie
     *
     * @param filename the file to read all the autocomplete data from each line
     *                 contains a word and its weight This method will call the
     *                 addWord method
     * @param k the maximum number of suggestions that should be displayed
     * @return the root of the Trie You might find the readLine() method in
     *         BufferedReader useful in this situation as it will allow you to
     *         read a file one line at a time.
     */
    @Override
    public Node buildTrie(String filename, int k) {
        
        // declare a filereader and buffered reader for reading
        FileReader fr = null;
        BufferedReader br = null;
        this.numSuggestions = k;
        
        try {
            // initialize the filereader and bufferedreader from the input autocomplete file
            fr = new FileReader(filename);
            br = new BufferedReader(fr);
            // read the header from the autocomplete file
            br.readLine();
            
            // loop until reaching a break statement
            while (true) {
                // read the next line from the bufferedwriter
                String record = br.readLine();
                // if the next line is null, break from the loop
                if (record == null) {
                    break;
                }
                
                // trim the read line and split on spaces
                String[] spt = record.trim().split("\\s+");
                // if the content of the line is empty strings, break from the loop
                if (spt[0].equals("") || spt[1].equals("")) {
                    break;
                }
                
                // parse the weight from the String array
                long w = Long.parseLong(spt[0]);
                // call the addWord function to add the String in spt[1] to the trie
                this.addWord(spt[1], w);
            }
            
            // close the buffered reader
            br.close();
            // return the root
            return this.root;

        } catch (IOException e) {
            // catch any IOExceptions thrown while reading
            e.printStackTrace();
        }
        
        // return null if file reading fails
        return null;
    }

    /**
     * @return k the the maximum number of suggestions that should be displayed
     */
    @Override
    public int numberSuggestions() {
        return this.numSuggestions;
    }

    /**
     * @param prefix
     * @return the root of the subTrie corresponding to the last character of
     *         the prefix.
     */
    @Override
    public Node getSubTrie(String prefix) {
        // edge cases:
        // return null for a null prefix
        if (prefix == null) {
            return null;
        }
        // if the prefix is an empty string, return the root
        if (prefix.trim().equals("")) {
            return this.root;
        }
        // return null if any character in the prefix is not an alphabetical character
        for (int i = 0; i < prefix.length(); i++) {
            if (!Character.isLetter(prefix.charAt(i))) {
                return null;
            }
        }

        // convert the prefix to lowercase; get the root Node
        String lowerPre = prefix.toLowerCase();
        Node node = this.root;

        // loop through the length of the prefix
        for (int i = 0; i < lowerPre.length(); i++) {
            // get each character from the prefix String
            char ch = lowerPre.charAt(i);
            // map the int value of the char to have 'a' as 0
            int index = ch - 'a';
            
            // if the next Node from the current node is null, return null
            if (node.getReferences()[index] == null) {
                return null;
            }
            // move to the next Node in the prefix string
            node = node.getReferences()[index];
        }

        // return the Node represented by the last char of the prefix String
        return node;
    }

    /**
     * @param prefix
     * @return the number of words that start with prefix.
     */
    @Override
    public int countPrefixes(String prefix) {
        // get the subTrie Node of the input prefix String
        Node subTrie = getSubTrie(prefix);
        // if the Node is null, return 0
        if (subTrie == null) {
            return 0;
        }
        // otherwise, return the number of prefix at that node
        return subTrie.getPrefixes();
    }

    /**
     * This method should not throw an exception
     * @param prefix
     * @return a List containing all the ITerm objects with query starting with
     *         prefix. Return an empty list if there are no ITerm object starting
     *         with prefix.
     */
    @Override
    public List<ITerm> getSuggestions(String prefix) {
        // initialize an empty arraylist to be filled with ITerm objects
        List<ITerm> list = new ArrayList<>();
        // get the subTrie Node corresponding to the input prefix
        Node node = this.getSubTrie(prefix);
        
        // call helper function to traverse the subTrie and return all terms
        this.traverseSubTrie(node, list);
        return list;
    }

    /**
     * Helper function used to traverse the subTrie from getSuggestions
     * Adds ITerm objects to the list to be returned while traversing the Trie
     * @param node current Node in the recursion process
     * @param list to add all ITerm objects to
     */
    private void traverseSubTrie(Node node, List<ITerm> list) {
        // if the current Node is null, do nothing
        if (node == null) {
            return;
        }
        
        // if the Node's Term object represents a word
        if (node.getWords() > 0) {
            // get the term from the node object
            Term t = node.getTerm();
            // get the query String from the term
            String query = t.getTerm();
            // get the term's weight
            long weight = t.getWeight();
            
            // add a new Term object, with appropriate String and weight, to the list
            list.add(new Term(query, weight));
        }
        
        // get the references of the current node and loop through all of them
        Node[] ref = node.getReferences();
        for (int i = 0; i < ref.length; i++) {
            // if the Node at index i of the references list is not null, recurse into it
            if (ref[i] != null) {
                this.traverseSubTrie(ref[i], list);
            }
        }
    }    
    
    /**
     * @return the autocomplete root
     */
    public Node getRoot() {
        return this.root;
    }

}
